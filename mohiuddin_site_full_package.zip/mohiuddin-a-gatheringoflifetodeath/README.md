MOHIUDDIN - Knowledge Archive
=============================
This package is ready to upload to your GitHub repository.
Steps:
1. Go to your GitHub repo (create one named mohiuddin-a-gatheringoflifetodeath if not already).
2. Upload all files (you can upload this zip content directly).
3. Enable Pages (Settings → Pages → main branch → root).
4. Visit https://<your-username>.github.io/mohiuddin-a-gatheringoflifetodeath/
5. Replace sample PDFs in uploads/ with your real PDF files.
