const REPO_BASE = '';
const DATA_FILE = 'data.json';
let DATA = { branches: [] };
let currentMain = null, currentSub = null, currentFolder = null;
const $ = id => document.getElementById(id);

const STR = {
  en: { mainBranches:'Main Branches', clickToOpen:'Click a branch to open sub-branches', selectPdf:'Select a PDF to view', download:'Download', adminTitle:'Admin (Local add)', adminHelp:'Use to test quickly — to make permanent, edit data.json in repo.', footer:'© 2025 Mohiuddin Bhuiyan — Maintain your knowledge library as PDFs.' },
  bn: { mainBranches:'প্রধান শাখাসমূহ', clickToOpen:'শাখায় ক্লিক করলে সাব-শাখা খোলা হবে', selectPdf:'পড়ার জন্য একটি PDF চয়ন কর', download:'ডাউনলোড', adminTitle:'অ্যাডমিন (লোকালি যোগ)', adminHelp:'দ্রুত পরীক্ষার জন্য। স্থায়ী করতে repo তে data.json সম্পাদন করো।', footer:'© 2025 Mohiuddin Bhuiyan — তোমার নলেজ লাইব্রেরি (PDF)।' }
};

let LANG = localStorage.getItem('site_lang') || 'en';
function setLanguage(lang){
  LANG = lang;
  $('langToggle').innerText = (lang==='en') ? 'বাংলা' : 'English';
  $('mainHeading').innerText = STR[lang].mainBranches;
  $('helpText').innerText = STR[lang].clickToOpen;
  $('viewerTitle').innerText = STR[lang].selectPdf;
  $('adminTitle').innerText = STR[lang].adminTitle;
  $('adminHelp').innerText = STR[lang].adminHelp;
  $('footerText').innerText = STR[lang].footer;
}

document.getElementById && document.addEventListener('DOMContentLoaded', ()=>{
  document.getElementById('langToggle').addEventListener('click', ()=>{ setLanguage(LANG==='en' ? 'bn' : 'en'); localStorage.setItem('site_lang', LANG); });
  document.getElementById('adminToggle').addEventListener('click', ()=>{ const p=document.getElementById('adminPanel'); p.style.display = p.style.display==='block'?'none':'block'; });
  document.getElementById('backMain').addEventListener('click', ()=>{ document.getElementById('subView').style.display='none'; document.getElementById('mainView').style.display='block'; });

  fetch(DATA_FILE + '?t=' + Date.now()).then(r=>r.json()).then(j=>{ DATA=j; renderMain(); setLanguage(LANG); }).catch(e=>{ console.warn('No data.json', e); DATA={branches:[]}; renderMain(); setLanguage(LANG); });
});

function renderMain(filter=''){
  const grid = $('branchesGrid'); grid.innerHTML='';
  const branches = DATA.branches || [];
  const list = filter ? branches.filter(b => b.name.toLowerCase().includes(filter.toLowerCase())) : branches;
  if(list.length===0){ grid.innerHTML = '<div class="branch"><h3>No branches</h3><p class="small">Edit data.json to add branches.</p></div>'; return; }
  list.forEach(b=>{ const el=document.createElement('div'); el.className='branch'; el.innerHTML=`<h3>${b.name}</h3><p>${b.summary||''}</p>`; el.addEventListener('click', ()=> openSub(b.name)); grid.appendChild(el); });
}

function openSub(name){
  currentMain = name;
  const branch = (DATA.branches||[]).find(x=>x.name===name);
  $('mainView').style.display='none'; $('subView').style.display='block'; $('crumbText').innerText = name;
  renderSub(branch);
}

function renderSub(branch){
  const subList = $('subList'); subList.innerHTML='';
  if(!branch || !branch.sub || branch.sub.length===0){ subList.innerHTML='<div class="small">No sub-branches yet.</div>'; return; }
  branch.sub.forEach(s=>{ const node=document.createElement('div'); node.style.padding='8px 0'; node.innerHTML=`<strong style="display:block">${s.name}</strong><div class="small">${s.description||''}</div>`; node.addEventListener('click', ()=>{ currentSub = s.name; renderFolderButtons(branch.name, s); }); subList.appendChild(node); });
}

function renderFolderButtons(mainName, subObj){
  const subList = $('subList'); subList.innerHTML='';
  const top = document.createElement('div'); top.className='folders';
  const b1 = document.createElement('div'); b1.className='folder-btn'; b1.innerText='Basic'; b1.addEventListener('click', ()=> showFiles(mainName, subObj, 'Basic'));
  const b2 = document.createElement('div'); b2.className='folder-btn'; b2.innerText='Advanced'; b2.addEventListener('click', ()=> showFiles(mainName, subObj, 'Advanced'));
  top.appendChild(b1); top.appendChild(b2); subList.appendChild(top);
  const info=document.createElement('div'); info.className='small'; info.style.marginTop='10px'; info.innerText = subObj.description || ''; subList.appendChild(info);
}

function showFiles(mainName, subObj, folder){
  currentFolder = folder;
  const subList = $('subList'); subList.innerHTML='';
  const top = document.createElement('div'); top.className='folders';
  const b1 = document.createElement('div'); b1.className='folder-btn'; b1.innerText='Basic'; b1.addEventListener('click', ()=> showFiles(mainName, subObj, 'Basic'));
  const b2 = document.createElement('div'); b2.className='folder-btn'; b2.innerText='Advanced'; b2.addEventListener('click', ()=> showFiles(mainName, subObj, 'Advanced'));
  top.appendChild(b1); top.appendChild(b2); subList.appendChild(top);
  const files = (subObj.files && subObj.files[folder]) ? subObj.files[folder] : [];
  if(!files || files.length===0){ const msg=document.createElement('div'); msg.className='small'; msg.style.padding='8px'; msg.innerText='No PDFs in this folder yet. Upload PDFs to repo and update data.json.'; subList.appendChild(msg); return; }
  files.forEach(p=>{ const row=document.createElement('div'); row.className='pdf-item'; const meta=document.createElement('div'); meta.className='meta'; meta.innerHTML=`<strong>${p.title}</strong><div class="small">${p.info||''}</div>`; const actions=document.createElement('div'); const viewBtn=document.createElement('button'); viewBtn.className='btn-outline'; viewBtn.innerText='View'; viewBtn.addEventListener('click', ()=> openPdf(p)); actions.appendChild(viewBtn); row.appendChild(meta); row.appendChild(actions); subList.appendChild(row); });
}

function openPdf(p){
  $('viewerTitle').innerText = p.title || STR[LANG].selectPdf;
  $('viewerPath').innerText = `${currentMain || ''} / ${currentSub || ''} / ${currentFolder || ''}`;
  const viewer = $('viewerArea'); viewer.innerHTML = '';
  const url = p.url.startsWith('http') ? p.url : (REPO_BASE + p.url);
  const iframe = document.createElement('iframe'); iframe.src = url;
  viewer.appendChild(iframe);
  $('downloadBtn').href = url;
  $('downloadBtn').innerText = STR[LANG].download;
}
